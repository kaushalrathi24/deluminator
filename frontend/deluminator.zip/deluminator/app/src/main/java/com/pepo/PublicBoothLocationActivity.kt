package com.pepo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

import com.pepo.helpers.sockets.SocketHandler


class PublicBoothLocationActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_public_booth_location)

        val coord_txt = findViewById<TextView>(R.id.coord_txt)
        val update_btn = findViewById<Button>(R.id.update_btn)


        update_btn.setOnClickListener{

        }
    }
}