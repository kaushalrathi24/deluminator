package com.pepo.helpers.hook.request

data class RequestModel(
    val email: String,
    val password: String
)
