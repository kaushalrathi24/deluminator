package com.pepo.helpers.hook.response


data class Booth(
    val _id: String,
    val username: String,
    val email: String
)