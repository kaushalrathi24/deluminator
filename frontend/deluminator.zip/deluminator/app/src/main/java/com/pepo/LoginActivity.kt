package com.pepo

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.widget.Button
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout

import androidx.core.graphics.drawable.DrawableCompat

import android.graphics.drawable.Drawable


class LoginActivity : AppCompatActivity() {

//    var placeholderBg: ConstraintLayout = findViewById(R.id.placeholder_signup)
//    var signupBg: ConstraintLayout = findViewById(R.id.signup_shape)
    var pubSelected = true
    var privSelected = false
    var loginState = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
//        placeholderBg= findViewById(R.id.placeholder_signup)
//        signupBg = findViewById(R.id.signup_shape)
        var placeholderBg = findViewById<ConstraintLayout>(R.id.placeholder_signup)
        var signupBg = findViewById<ConstraintLayout>(R.id.signup_shape)
        var login_text = findViewById<TextView>(R.id.login_text)
        var p_signup_text = findViewById<TextView>(R.id.placeholder_signup_text)
        var sign_btn = findViewById<Button>(R.id.sign_btn)
        var pub_btn = findViewById<Button>(R.id.pub_btn)
        var private_btn = findViewById<Button>(R.id.private_btn)

        login_text.setOnClickListener{
            placeholderBg.visibility = VISIBLE
            signupBg.visibility = GONE
            sign_btn.text = "SIGN IN"
            loginState = true
        }

        p_signup_text.setOnClickListener{
            placeholderBg.visibility = GONE
            signupBg.visibility = VISIBLE
            sign_btn.text = "SIGN UP"
            loginState = false

        }

        pub_btn.setOnClickListener{

            var buttonDrawable: Drawable? = pub_btn.getBackground()
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.parseColor("#44ace4"))

            pub_btn.setBackground(buttonDrawable)

//            pub_btn.setBackgroundColor(Color.parseColor("#0057FF"))

            var buttonDrawable2: Drawable? = private_btn.getBackground()
            buttonDrawable2 = DrawableCompat.wrap(buttonDrawable2!!)
            DrawableCompat.setTint(buttonDrawable2, Color.parseColor("#9CD3EC"))

            private_btn.setBackground(buttonDrawable2)
//            private_btn.setBackgroundColor(Color.parseColor("#9CD3EC"))

            pubSelected = true
            privSelected = false
        }

        private_btn.setOnClickListener {

            var buttonDrawable3: Drawable? = private_btn.getBackground()
            buttonDrawable3 = DrawableCompat.wrap(buttonDrawable3!!)
            DrawableCompat.setTint(buttonDrawable3, Color.parseColor("#44ace4"))

            private_btn.setBackground(buttonDrawable3)

//            private_btn.setBackgroundColor(Color.parseColor("#0057FF"))

            var buttonDrawable4: Drawable? = pub_btn.getBackground()
            buttonDrawable4 = DrawableCompat.wrap(buttonDrawable4!!)
            DrawableCompat.setTint(buttonDrawable4, Color.parseColor("#9CD3EC"))

            pub_btn.setBackground(buttonDrawable4)
            pubSelected = false
            privSelected = true



        }

        sign_btn.setOnClickListener{


            if (loginState){
                val intent = Intent(this, HomeActivity::class.java)
                startActivity(intent)
            }
            else if (pubSelected){
                val intent = Intent(this, PublicBoothLocationActivity::class.java)
                startActivity(intent)
            }else if (privSelected){
                val intent = Intent(this, HomeActivity::class.java)
                startActivity(intent)
            }


        }

    }

    fun openAR(view: View) {
        val intent = Intent(this, MapActivity::class.java)
        startActivity(intent)

    }


}