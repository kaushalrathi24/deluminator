package com.pepo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.Toast
import androidx.fragment.app.FragmentTransaction
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.pepo.helpers.sockets.SocketHandler

class HomeActivity : AppCompatActivity() {

    lateinit var boothsFragment: boothsFragment
    lateinit var friendsFragment: friendsFragment
    lateinit var groupsFragment: groupsFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        var bottomnav = findViewById<BottomNavigationView>(R.id.BottomNavMenu)
        var frame = findViewById<FrameLayout>(R.id.frameLayout)

        var reqLocBtn = findViewById<Button>(R.id.reqLocBtn)
        var sendLocBtn = findViewById<Button>(R.id.sendLocBtn)

        SocketHandler.setSocket()
        SocketHandler.establishConnection()
        val mSocket = SocketHandler.getSocket()
        mSocket.emit("auth")




        reqLocBtn.setOnClickListener{

            mSocket.emit("requestLocation","41e1ee89-a09b-446a-9164-c4103fd514bb")

            mSocket.on("approveLocation") { args ->
                if (args[0] != null) {
                    val userId = args[0]
                    runOnUiThread {
                        mSocket.emit("approvedLocation","41e1ee89-a09b-446a-9164-c4103fd514bb")
                    }
                }
            }

            SocketHandler.closeConnection()

        }

        sendLocBtn.setOnClickListener {

            mSocket.emit("sendLocation","41e1ee89-a09b-446a-9164-c4103fd514bb")

        }



        friendsFragment = friendsFragment()
        supportFragmentManager
            .beginTransaction()
            .replace(R.id.frameLayout,friendsFragment)
            .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
            .commit()

        bottomnav.setOnNavigationItemSelectedListener { item ->
            //we will select each menu item and add an event when it's selected
            when(item.itemId){
                R.id.friend -> {
                    friendsFragment = friendsFragment()
                    supportFragmentManager
                        .beginTransaction()
                        .replace(R.id.frameLayout,friendsFragment)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                        .commit()
                }
                R.id.booth -> {
                    boothsFragment = boothsFragment()
                    supportFragmentManager
                        .beginTransaction()
                        .replace(R.id.frameLayout,boothsFragment)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                        .commit()
                }

                R.id.group -> {
                    groupsFragment = groupsFragment()
                    supportFragmentManager
                        .beginTransaction()
                        .replace(R.id.frameLayout,groupsFragment)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                        .commit()
                }
            }

            true
        }
    }




}