package com.pepo.helpers.hook

import com.pepo.helpers.hook.request.RequestModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit

class RestApiService {
    fun addUser(userData: RequestModel, onResult: (RequestModel?) -> Unit){
        val retrofit = ServiceBuilder.buildService(RestApi::class.java)
        retrofit.addUser(userData).enqueue(
            object : Callback<RequestModel> {
                override fun onFailure(call: Call<RequestModel>, t: Throwable) {
                    onResult(null)
                }
                override fun onResponse( call: Call<RequestModel>, response: Response<RequestModel>) {
                    val addedUser = response.body()
                    onResult(addedUser)
                }
            }
        )
    }
}