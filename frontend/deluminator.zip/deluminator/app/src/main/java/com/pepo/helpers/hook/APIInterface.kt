package com.pepo.helpers.hook

import com.pepo.helpers.hook.request.RequestModel
import com.pepo.helpers.hook.response.ResponseModel
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST

interface RestApi {

    @Headers("Content-Type: application/json")
    @POST("users")
    fun addUser(@Body userData: RequestModel): Call<RequestModel>
}