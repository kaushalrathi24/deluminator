package com.pepo.helpers.hook.response

data class Friend(
    val _id: String,
    val username: String,
    val email: String

)