package com.pepo.helpers.sockets

import io.socket.client.IO
import io.socket.client.Socket
import java.net.URISyntaxException

object SocketHandler {

    lateinit var mSocket: Socket

    @Synchronized
    fun setSocket() {
        try {
            mSocket = IO.socket("http://206.189.143.58:3002/?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiZjRmZjMwY2YtNGExNy00ZjYwLThkMDctOWFlNDg3YzFjMzk3IiwiZW1haWwiOiJlbWFpbDEiLCJpYXQiOjE2NjQ2MzIyMTV9.kD8Jpk61MUYQ5nuYz1HxBVYAdR2bgGFKz5vosd_35h4")
        } catch (e: URISyntaxException) {

        }
    }

    @Synchronized
    fun getSocket(): Socket {
        return mSocket
    }

    @Synchronized
    fun establishConnection() {
        mSocket.connect()
    }

    @Synchronized
    fun closeConnection() {
        mSocket.disconnect()
    }
}