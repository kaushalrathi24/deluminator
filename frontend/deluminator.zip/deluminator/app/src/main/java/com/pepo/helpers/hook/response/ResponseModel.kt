package com.pepo.helpers.hook.response

data class ResponseModel(
    val type: String,
    val friends: List<Friend>,
    val booths: List<Booth>

)

