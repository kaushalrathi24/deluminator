package com.pepo

import android.opengl.Matrix
import android.util.Log
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.google.android.gms.maps.model.LatLng
import com.google.ar.core.Anchor
import com.google.ar.core.TrackingState
import com.pepo.examples.java.common.helpers.DisplayRotationHelper
import com.pepo.examples.java.common.helpers.TrackingStateHelper
import com.pepo.examples.java.common.samplerender.Framebuffer
import com.pepo.examples.java.common.samplerender.Mesh
import com.pepo.examples.java.common.samplerender.SampleRender
import com.pepo.examples.java.common.samplerender.Shader
import com.pepo.examples.java.common.samplerender.Texture
import com.pepo.examples.java.common.samplerender.arcore.BackgroundRenderer
import com.google.ar.core.exceptions.CameraNotAvailableException
import com.pepo.helpers.sockets.SocketHandler
import java.io.IOException
import kotlin.math.sqrt


class EarthRenderer(val activity: MapActivity) :
  SampleRender.Renderer, DefaultLifecycleObserver {
  //ARCore initialization>
  companion object {
    val TAG = "HelloGeoRenderer"

    private val Z_NEAR = 0.1f
    private val Z_FAR = 1000f
  }

  lateinit var backgroundRenderer: BackgroundRenderer
  lateinit var virtualSceneFramebuffer: Framebuffer
  var hasSetTextureNames = false

  // Virtual object (ARCore pawn)
  lateinit var virtualObjectMesh: Mesh
  lateinit var virtualObjectShader: Shader
  lateinit var virtualObjectTexture: Texture

  // Temporary matrix allocated
  val modelMatrix = FloatArray(16)
  val viewMatrix = FloatArray(16)
  val projectionMatrix = FloatArray(16)
  val modelViewMatrix = FloatArray(16) // view x model

  val modelViewProjectionMatrix = FloatArray(16) // projection x view x model

  val session
    get() = activity.arCoreSessionHelper.session

  val displayRotationHelper = DisplayRotationHelper(activity)
  val trackingStateHelper = TrackingStateHelper(activity)



  override fun onResume(owner: LifecycleOwner) {
    displayRotationHelper.onResume()
    hasSetTextureNames = false
  }

  override fun onPause(owner: LifecycleOwner) {
    displayRotationHelper.onPause()
  }

  override fun onSurfaceCreated(render: SampleRender) {
    // Prepare the rendering objects.
    // This involves reading shaders and 3D model files, so may throw an IOException.
    try {
      backgroundRenderer = BackgroundRenderer(render)
      virtualSceneFramebuffer = Framebuffer(render, /*width=*/ 1, /*height=*/ 1)

      // Virtual object to render (Geospatial Marker)
      virtualObjectTexture =
        Texture.createFromAsset(
          render,
          "models/spatial_marker_baked.png",
          Texture.WrapMode.CLAMP_TO_EDGE,
          Texture.ColorFormat.SRGB
        )

      virtualObjectMesh = Mesh.createFromAsset(render, "models/geospatial_marker.obj");
      virtualObjectShader =
        Shader.createFromAssets(
          render,
          "shaders/ar_unlit_object.vert",
          "shaders/ar_unlit_object.frag",
          /*defines=*/ null)
          .setTexture("u_Texture", virtualObjectTexture)

      backgroundRenderer.setUseDepthVisualization(render, false)
      backgroundRenderer.setUseOcclusion(render, false)
    } catch (e: IOException) {
      Log.e(TAG, "Failed to read a required asset file", e)
      showError("Failed to read a required asset file: $e")
    }
  }

  override fun onSurfaceChanged(render: SampleRender, width: Int, height: Int) {
    displayRotationHelper.onSurfaceChanged(width, height)
    virtualSceneFramebuffer.resize(width, height)


  }
  //</editor-fold>

  override fun onDrawFrame(render: SampleRender) {
    val session = session ?: return

    //<editor-fold desc="ARCore frame boilerplate" defaultstate="collapsed">
    if (!hasSetTextureNames) {
      session.setCameraTextureNames(intArrayOf(backgroundRenderer.cameraColorTexture.textureId))
      hasSetTextureNames = true
    }


    // Notify ARCore session that the view size changed

    displayRotationHelper.updateSessionIfNeeded(session)

    // Obtain the current frame from ARSession.

    val frame =
      try {
        session.update()
      } catch (e: CameraNotAvailableException) {
        Log.e(TAG, "Camera not available during onDrawFrame", e)
        showError("Camera not available. Try restarting the app.")
        return
      }

    val camera = frame.camera

    // BackgroundRenderer.updateDisplayGeometry must be called every frame

    backgroundRenderer.updateDisplayGeometry(frame)

    // Keep the screen unlocked while tracking, but allow it to lock when tracking stops.
    trackingStateHelper.updateKeepScreenOnFlag(camera.trackingState)

    // -- Draw background
    if (frame.timestamp != 0L) {
      // Suppress rendering if the camera did not produce the first frame yet. This is to avoid
      // drawing possible leftover data from previous sessions if the texture is reused.
      backgroundRenderer.drawBackground(render)
    }

    // If not tracking, don't draw 3D objects.
    if (camera.trackingState == TrackingState.PAUSED) {
      return
    }

    // Get projection matrix.
    camera.getProjectionMatrix(projectionMatrix, 0, Z_NEAR, Z_FAR)

    // Get camera matrix and draw.
    camera.getViewMatrix(viewMatrix, 0)

    render.clear(virtualSceneFramebuffer, 0f, 0f, 0f, 0f)
    //</editor-fold>

    // TODO: Obtain Geospatial information and display it on the map.
    SocketHandler.setSocket()
    SocketHandler.establishConnection()
    val mSocket = SocketHandler.getSocket()

    val earth = session.earth
    if (earth?.trackingState == TrackingState.TRACKING) {
      // TODO: the Earth object may be used here.
      val cameraGeospatialPose = earth.cameraGeospatialPose
      activity.view.mapView?.updateMapPosition(
        latitude = cameraGeospatialPose.latitude,
        longitude = cameraGeospatialPose.longitude,
        heading = cameraGeospatialPose.heading
      )
      activity.view.updateStatusText(earth, cameraGeospatialPose)

//      val userInfo = UserInfo()
      mSocket.emit("auth")
      mSocket.emit("sendLocation","41e1ee89-a09b-446a-9164-c4103fd514bb",cameraGeospatialPose.latitude,cameraGeospatialPose.longitude)
//      mSocket.on("receiveLocation") { args ->
//        if (args[0] != null) {
//          val userId = args[0] as String
//          val laat = args[1] as Double
//          val loong = args[2] as Double
//          mapOn
//        }
//      }
//
    }

    // Draw the placed anchor, if it exists.
    earthAnchor?.let {
      render.renderCompassAtAnchor(it)
    }

    // Compose the virtual scene with the background.
    backgroundRenderer.drawVirtualScene(render, virtualSceneFramebuffer, Z_NEAR, Z_FAR)

//    mSocket.disconnect()

  }

  var earthAnchor: Anchor? = null

  fun distance(p1: LatLng, p2: LatLng): Double {
    val xDiff = (p1.latitude - p2.latitude).toDouble()
    val yDiff = (p1.longitude - p2.longitude).toDouble()
    return sqrt(xDiff * xDiff + yDiff * yDiff)
  }


  fun onMapClick(latLng: LatLng) {
    // TODO: place an anchor at the given position.
    val earth = session?.earth ?: return
    val cameraGeospatialPose = earth.cameraGeospatialPose
    val latitude = cameraGeospatialPose.latitude
    val longitude = cameraGeospatialPose.longitude
    if (earth.trackingState != TrackingState.TRACKING) {
      return
    }




//    val atLng = LatLng(latitude,longitude)
    earthAnchor?.detach()
    // Place the earth anchor at the same altitude as that of the camera to make it easier to view.
    val altitude = earth.cameraGeospatialPose.altitude - 1
    // The rotation quaternion of the anchor
    val qx = 0f
    val qy = 0f
    val qz = 0f
    val qw = 1f



    earthAnchor = earth.createAnchor(latLng.latitude,  latLng.longitude, altitude, qx, qy, qz, qw)//latLng.latitude, latLng.longitude,
    activity.view.mapView?.earthMarker?.apply {
      position = latLng
      isVisible = true
    }
  }



  private fun SampleRender.renderCompassAtAnchor(anchor: Anchor) {
    // Get the current pose of the Anchor in world space.
    anchor.pose.toMatrix(modelMatrix, 0)

    // Calculate model/view/projection matrices
    Matrix.multiplyMM(modelViewMatrix, 0, viewMatrix, 0, modelMatrix, 0)
    Matrix.multiplyMM(modelViewProjectionMatrix, 0, projectionMatrix, 0, modelViewMatrix, 0)

    // Update shader properties and draw
    virtualObjectShader.setMat4("u_ModelViewProjection", modelViewProjectionMatrix)
    draw(virtualObjectMesh, virtualObjectShader, virtualSceneFramebuffer)
  }

  private fun showError(errorMessage: String) =
    activity.view.snackbarHelper.showError(activity, errorMessage)
}
